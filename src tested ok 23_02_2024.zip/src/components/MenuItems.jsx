// export const MenuItems = [
//     {
//         title : "Home",
//         url :"/",
//         cName :"nav-links" 
//     },
    
//     // {
//     //     title : "About",
//     //     url :"/about",
//     //     cName :"nav-links" 
//     // },
//     {
//         title : "Defence",
//         url :"/defence",
//         cName :"nav-links" 
//     },
//     {
//         title : "Education",
//         url :"/education",
//         cName :"nav-links" 
//     },
//     // {
//     //     title : "Finance",
//     //     url :"/finance",
//     //     cName :"nav-links" 
//     // },
//     {
//         title : "Profile",
//         url :"/profile",
//         cName :"nav-links" 
//     },
//     { ( localStorage.getItem('role') === 'ADMIN') && (
//         {
//          title : "UserList",
//          url :"/getAllUsers",
//          cName :"nav-links" 
//      },)}
//      {
//         // <Link className="nav-links" to="/login" > log in</Link>
//         // <Link className="nav-links" to="/signUp" > Sign Up</Link>
//         // <Link className="nav-links" to="/aadminloggedin" >admin log</Link>

//      },
//     {
//         // title : "Sign up",
//         // url :"/signUp",
//         // cName :"nav-links" 
//     },
//     {
//         // title : "Admin-login",
//         // url :"/adminloggedin",
//         // cName :"nav-links" 
//     }
// ]

export const MenuItems = [
    {
      title: "Home",
      url: "/",
      cName: "nav-links",
    },
    {
      title: "Defence",
      url: "/defence",
      cName: "nav-links",
    },
    {
      title: "Education",
      url: "/education",
      cName: "nav-links",
    },
    {
      title: "Profile",
      url: "/profile",
      cName: "nav-links",
    },

    ...(localStorage.getItem('role') === 'ADMIN'
      ? [
          {
            title: "UserList",
            url: "/getAllUsers",
            cName: "nav-links",
          },
        ]
      : []),
  ];